
public class Pez extends Animal {
    public Pez() {
        super();
        this.tipoAnimal = "Pez";
        // TODO Auto-generated constructor stub
    }

}
