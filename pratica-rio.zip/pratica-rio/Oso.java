
public class Oso extends Animal {

	public Oso() {
		super();
		this.tipoAnimal = "Oso";
		// TODO Auto-generated constructor stub
	}

}
